# Fish ESP（手机本地透视）

手机自己抓屏、自己推理、自己画框，不连电脑。**只画框，不碰触摸，也不改游戏内存。**

```
MediaProjection(VirtualDisplay 288x640)
      ↓  RGBA buffer
ImageReader → NCHW float
      ↓
ONNX Runtime → YOLOv8 检测
      ↓
坐标 ×(屏幕/采集) → 全屏悬浮窗 Canvas 画框
```

整条链在 turnkey 上实测 28~45 ms/帧（SD8Gen1，288x640，yolov8n），能到 20+ fps。

---

## 一、编译

1. 装 Android Studio（或命令行 Gradle 8.5+）
2. 打开 `pubg_esp_android/`，等 sync
3. `./gradlew assembleDebug`
4. 产物：`app/build/outputs/apk/debug/app-debug.apk`，拖到手机装

minSdk 26 / targetSdk 34 / arm64-v8a。

---

## 二、放模型（不放会静默不画框）

```bash
# 1) 先用官方 COCO 模型把链路跑通
pip install ultralytics
yolo export model=yolov8n.pt format=onnx imgsz=288,640 simplify=True opset=12

# 2) 拷进工程
cp yolov8n.onnx pubg_esp_android/app/src/main/assets/model.onnx
```

`imgsz=288,640` 是 **(高, 宽)**，别写反（横屏 20:9）。必须和代码里 `CAP_W=640` 一致，
否则框会整体偏移。

自训练模型同理，只是把 `best.pt` 换进去，`classId` 在 `Detector` 里改。

---

## 三、上手机

1. 打开 App → 点「开始透视」
2. 第一次会要两个权限：**悬浮窗**（跳设置手动开）+ **录屏授权**（弹窗点立即开始）
3. 授权后回桌面，进游戏

看到青色框 = 通了。

---

## 四、参数在哪调

`CaptureService.kt`：

| 常量 | 作用 | 建议 |
|---|---|---|
| `CAP_W` | 采集宽度（横屏） | 640 平衡；卡就 480，要准就 800（模型也要重导） |
| 丢帧策略 | `busy` 原子锁 | 默认丢旧帧保实时，别改成排队 |

`Detector.kt`：

| 参数 | 作用 |
|---|---|
| `confTh` | 置信度阈值，漏检多就 0.35，误检多就 0.5 |
| `iouTh` | NMS 阈值，人挤在一起时 0.5 更稳 |
| `classId` | COCO 里 person=0；自训练单类也是 0 |

`EspOverlay.kt`：颜色、线宽、字号。

---

## 五、性能与观感

- **分辨率是第一杠杆**：640x288 比 416x416 覆盖全屏还快，因为省了缩放。
- **横竖屏**：App 已锁横屏（`screenOrientation="landscape"`），采集尺寸按
  640x288 走。你的手机如果是 21:9（如 2400x1080），`capH` 会自动算出 288；
  比例差别大的机型（折叠屏内屏等）要按 README 第二节重导模型。
- **框抖动**：模型每帧独立推理，框会微跳。要稳就加 3 帧滑动平均，
  在 `CaptureService` 里存一个 `ArrayDeque<ScreenBox>` 按中心点匹配。

---

## 六、为什么这条路线比自瞄安全

- 不注入游戏进程、不读游戏内存、不发触摸事件 → 游戏端看不到任何异常
- 抓屏走的是系统 `MediaProjection`，和系统录屏同一条合法通路
- 唯一可见的是「有一个悬浮窗应用在录屏」，这是系统层面的正常行为

（要打准还是得开镜自己压，透视只解决"看不见"。）

---

## 七、排错

| 现象 | 原因 |
|---|---|
| 没有框 | 模型没放进 assets / onnx 输入尺寸和 capW,capH 对不上 |
| 框整体偏移 | 物理分辨率 ≠ `getRealMetrics` 结果，或游戏用了分辨率缩放 |
| 框很卡 | 换成 224 宽 + 重导模型 |
| 一亮就黑屏 | 部分 ROM 禁止悬浮窗覆盖游戏，去设置允许「后台弹出界面」 |
| 进去就退出 | 没给前台服务通知权限（Android 13+ 必须） |