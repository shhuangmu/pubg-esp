package com.fish.esp

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.res.AssetManager
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min

data class Box(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val score: Float)

/**
 * YOLOv8 ONNX 推理。
 *
 * 模型导出务必用和 capture 相同的宽高比，比如屏幕 20:9 就导 imgsz=[288,640]：
 *   yolo export model=best.pt format=onnx imgsz=288,640 simplify=True opset=12
 * 这样不用 letterbox，框直接是「屏幕等比坐标」，快且不丢两侧视野。
 */
class Detector(
    assets: AssetManager,
    modelName: String = "model.onnx",
    val inputW: Int = 640,
    val inputH: Int = 288,
    private val confTh: Float = 0.40f,
    private val iouTh: Float = 0.45f,
    private val classId: Int = 0,
) {
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inputName: String

    /** 模型输出是 [1, 4+nc, N]，缓存一下 N 和 nc 免得每帧解析 */
    private var numClasses = -1

    init {
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        val bytes = assets.open(modelName).use { it.readBytes() }
        session = env.createSession(bytes, opts)
        inputName = session.inputNames.first()
    }

    /**
     * @param nchw 已归一化的 FloatArray，长度 3*inputH*inputW，通道优先
     * @return 框（坐标在 inputW x inputH 空间）
     */
    @Suppress("UNCHECKED_CAST")
    fun detect(nchw: FloatArray): List<Box> {
        val shape = longArrayOf(1, 3, inputH.toLong(), inputW.toLong())
        val tensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(nchw), shape)
        var raw: Array<Array<FloatArray>>? = null
        tensor.use {
            session.run(mapOf(inputName to it)).use { res ->
                raw = res[0].value as Array<Array<FloatArray>>
            }
        }
        val out = raw ?: return emptyList()
        val ch = out[0].size          // 4 + nc
        val n = out[0][0].size        // anchors
        if (numClasses < 0) numClasses = ch - 4

        val boxes = ArrayList<Box>(64)
        val cxArr = out[0][0]
        val cyArr = out[0][1]
        val wArr = out[0][2]
        val hArr = out[0][3]
        val scoreArr = if (numClasses == 1) out[0][4] else out[0][4 + classId]

        for (i in 0 until n) {
            val s = scoreArr[i]
            if (s < confTh) continue
            val cx = cxArr[i]; val cy = cyArr[i]
            val w = wArr[i]; val h = hArr[i]
            val x1 = (cx - w / 2f).coerceIn(0f, inputW.toFloat())
            val y1 = (cy - h / 2f).coerceIn(0f, inputH.toFloat())
            val x2 = (cx + w / 2f).coerceIn(0f, inputW.toFloat())
            val y2 = (cy + h / 2f).coerceIn(0f, inputH.toFloat())
            if (x2 - x1 < 4f || y2 - y1 < 8f) continue
            boxes.add(Box(x1, y1, x2, y2, s))
        }
        return nms(boxes, iouTh)
    }

    private fun nms(src: List<Box>, iouTh: Float): List<Box> {
        if (src.size <= 1) return src
        val sorted = src.sortedByDescending { it.score }
        val keep = ArrayList<Box>(sorted.size)
        val removed = BooleanArray(sorted.size)
        for (i in sorted.indices) {
            if (removed[i]) continue
            val a = sorted[i]
            keep.add(a)
            for (j in i + 1 until sorted.size) {
                if (removed[j]) continue
                if (iou(a, sorted[j]) > iouTh) removed[j] = true
            }
        }
        return keep
    }

    private fun iou(a: Box, b: Box): Float {
        val ix1 = max(a.x1, b.x1); val iy1 = max(a.y1, b.y1)
        val ix2 = min(a.x2, b.x2); val iy2 = min(a.y2, b.y2)
        val iw = ix2 - ix1; val ih = iy2 - iy1
        if (iw <= 0 || ih <= 0) return 0f
        val inter = iw * ih
        val union = (a.x2 - a.x1) * (a.y2 - a.y1) + (b.x2 - b.x1) * (b.y2 - b.y1) - inter
        return if (union <= 0f) 0f else inter / union
    }

    fun close() {
        session.close()
    }
}