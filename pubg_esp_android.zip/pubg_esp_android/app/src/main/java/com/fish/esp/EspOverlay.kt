package com.fish.esp

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * 全屏透明悬浮层。只画，不接收触摸（FLAG_NOT_TOUCHABLE），
 * 游戏照常响应你的手指。
 */
class EspOverlay(private val context: Context) {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var view: OverlayView? = null
    private var added = false

    @SuppressLint("InflateParams")
    fun show() {
        if (added) return
        val v = OverlayView(context)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0; y = 0
        }
        wm.addView(v, lp)
        view = v
        added = true
    }

    /** 主线程更新框 */
    fun update(boxes: List<ScreenBox>) {
        main.post { view?.setBoxes(boxes) }
    }

    fun hide() {
        if (!added) return
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        added = false
    }
}

data class ScreenBox(val l: Float, val t: Float, val r: Float, val b: Float, val score: Float)

class OverlayView(context: Context) : View(context) {

    private var boxes: List<ScreenBox> = emptyList()

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
        color = Color.parseColor("#00E5FF")
        setShadowLayer(6f, 0f, 0f, Color.parseColor("#33000000"))
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#2200E5FF")
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF3B3B")
        textSize = 26f
        isFakeBoldText = true
    }

    fun setBoxes(b: List<ScreenBox>) {
        boxes = b
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (b in boxes) {
            val r = RectF(b.l, b.t, b.r, b.b)
            canvas.drawRect(r, fillPaint)
            canvas.drawRect(r, stroke)
            // 框顶一条实线，方便眼睛抓
            canvas.drawLine(b.l, b.t, b.r, b.t, stroke)
            val label = "${(b.score * 100).toInt()}%"
            canvas.drawText(label, b.l, maxOf(b.t - 6f, 30f), textPaint)
        }
    }
}