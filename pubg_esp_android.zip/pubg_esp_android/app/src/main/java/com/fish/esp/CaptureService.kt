package com.fish.esp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

/**
 * 抓屏 -> 推理 -> 画框，一条流水线。
 *
 * 关键取舍：VirtualDisplay 直接输出模型输入尺寸（例如 288x640），
 * 省掉一次缩放，抓到的 buffer 只做 RGBA -> NCHW 的搬运。
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val CAP_W = 640          // 基准宽（横屏），够用且快
        private const val CH_ID = "esp"
        private const val TAG = "FishESP"
        /** 上一帧没算完就丢帧，避免排队越积越多 */
        private var capW = CAP_W
        private var capH = 288
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private var detector: Detector? = null
    private var overlay: EspOverlay? = null
    private val busy = AtomicBoolean(false)

    private var screenW = 1080
    private var screenH = 2400

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "projection stopped by system")
            teardown()
            stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        overlay = EspOverlay(this).also { it.show() }
        val t = HandlerThread("cap").also { it.start() }
        thread = t
        handler = Handler(t.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mgr.getMediaProjection(code, data) ?: run { stopSelf(); return START_NOT_STICKY }
        projection = p

        // Android 14：mediaProjection 类型的前台服务必须拿到 token 之后再 startForeground，
        // 否则直接 SecurityException 崩掉。
        val type = if (Build.VERSION.SDK_INT >= 29)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        ServiceCompat.startForeground(this, 1, buildNotification(), type)

        if (Build.VERSION.SDK_INT >= 34) p.registerCallback(projectionCallback, handler)

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        // 横屏优先：宽取长边，避免某些 ROM 在旋转瞬间返回竖值
        screenW = maxOf(dm.widthPixels, dm.heightPixels)
        screenH = minOf(dm.widthPixels, dm.heightPixels)

        capW = CAP_W
        // 高度取和屏幕同比例、且是 32 的倍数（YOLO 的 stride 是 32）
        capH = ((CAP_W.toFloat() * screenH / screenW) / 32f).roundToInt() * 32
        Log.i(TAG, "screen=${screenW}x$screenH cap=${capW}x$capH")

        detector = runCatching { Detector(assets, "model.onnx", capW, capH) }
            .onFailure { Log.e(TAG, "模型加载失败：把 model.onnx 放进 app/src/main/assets/", it) }
            .getOrNull()

        startCapture(p)
        return START_STICKY
    }

    private fun startCapture(p: MediaProjection) {
        reader?.close()
        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = p.createVirtualDisplay(
            "esp", capW, capH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )
        val nchw = FloatArray(3 * capW * capH)
        r.setOnImageAvailableListener({ ir ->
            val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (!busy.compareAndSet(false, true)) return@setOnImageAvailableListener
                fillNchw(image, nchw)
                val det = detector ?: return@setOnImageAvailableListener
                val boxes = det.detect(nchw)
                if (boxes.isNotEmpty()) {
                    val sx = screenW.toFloat() / capW
                    val sy = screenH.toFloat() / capH
                    val out = boxes.map { b ->
                        ScreenBox(b.x1 * sx, b.y1 * sy, b.x2 * sx, b.y2 * sy, b.score)
                    }
                    overlay?.update(out)
                } else {
                    overlay?.update(emptyList())
                }
            } catch (e: Exception) {
                Log.w(TAG, "frame failed", e)
            } finally {
                busy.set(false)
                image.close()
            }
        }, handler)
    }

    /** RGBA_8888 -> NCHW float，注意 rowStride 可能带 padding */
    private fun fillNchw(image: Image, out: FloatArray) {
        val plane = image.planes[0]
        val buf = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val w = image.width
        val h = image.height
        val n = w * h
        buf.rewind()
        val bytes = ByteArray(buf.remaining())
        buf.get(bytes)
        for (y in 0 until h) {
            val base = y * rowStride
            val row = y * w
            for (x in 0 until w) {
                val i = base + x * pixelStride
                val p = row + x
                out[p] = (bytes[i].toInt() and 0xFF) / 255f             // R
                out[n + p] = (bytes[i + 1].toInt() and 0xFF) / 255f     // G
                out[2 * n + p] = (bytes[i + 2].toInt() and 0xFF) / 255f // B
            }
        }
    }

    private fun teardown() {
        runCatching { vd?.release() }
        runCatching { reader?.close() }
        runCatching { detector?.close() }
        vd = null; reader = null; detector = null
        overlay?.hide()
    }

    override fun onDestroy() {
        teardown()
        runCatching { projection?.stop() }
        thread?.quitSafely()
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_ID, "透视", NotificationManager.IMPORTANCE_MIN)
        )
    }

    private fun buildNotification(): Notification =
        Notification.Builder(this, CH_ID)
            .setContentTitle("Fish ESP 运行中")
            .setContentText("返回游戏即可")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
}